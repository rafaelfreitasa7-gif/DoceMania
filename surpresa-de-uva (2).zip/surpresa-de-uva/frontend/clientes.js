async function carregarClientes() {
  const resposta = await fetch("/api/clientes");
  const clientes = await resposta.json();
  const tbody = document.getElementById("listaClientes");

  tbody.innerHTML = "";

  clientes.forEach(cliente => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${cliente.nome}</td>
      <td>${cliente.telefone || "-"}</td>
      <td>
        <button class="action delete" onclick="excluirCliente(${cliente.id})">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById("clienteForm").addEventListener("submit", async event => {
  event.preventDefault();

  const nome = document.getElementById("nome").value;
  const telefone = document.getElementById("telefone").value;

  const resposta = await fetch("/api/clientes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, telefone })
  });

  const dados = await resposta.json();

  if (!resposta.ok) {
    alert(dados.erro);
    return;
  }

  event.target.reset();
  carregarClientes();
  alert("Cliente cadastrado com sucesso!");
});

async function excluirCliente(id) {
  if (!confirm("Deseja excluir este cliente?")) return;

  const resposta = await fetch(`/api/clientes/${id}`, { method: "DELETE" });
  const dados = await resposta.json();

  if (!resposta.ok) {
    alert(dados.erro);
    return;
  }

  carregarClientes();
}

carregarClientes();