let produtos = [];
let carrinho = [];

const dinheiro = valor =>
  Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

async function carregarDados() {
  const [resProdutos, resClientes, resVendas] = await Promise.all([
    fetch("/api/produtos"),
    fetch("/api/clientes"),
    fetch("/api/vendas")
  ]);

  produtos = await resProdutos.json();
  const clientes = await resClientes.json();
  const vendas = await resVendas.json();

  const clienteSelect = document.getElementById("cliente");
  clienteSelect.innerHTML = '<option value="">Cliente não informado</option>';

  clientes.forEach(cliente => {
    clienteSelect.innerHTML += `<option value="${cliente.id}">${cliente.nome}</option>`;
  });

  atualizarSelectProdutos();
  renderizarHistorico(vendas);
}

function atualizarSelectProdutos() {
  const select = document.getElementById("produto");
  select.innerHTML = "";

  produtos.filter(p => p.estoque > 0).forEach(produto => {
    select.innerHTML += `
      <option value="${produto.id}">
        ${produto.nome} — ${dinheiro(produto.preco)} (${produto.estoque} disponíveis)
      </option>
    `;
  });
}

document.getElementById("adicionar").addEventListener("click", () => {
  const produtoId = Number(document.getElementById("produto").value);
  const quantidade = Number(document.getElementById("quantidade").value);
  const produto = produtos.find(p => p.id === produtoId);

  if (!produto) {
    alert("Cadastre um produto com estoque antes de realizar a venda.");
    return;
  }

  if (!Number.isInteger(quantidade) || quantidade <= 0) {
    alert("Informe uma quantidade válida.");
    return;
  }

  const existente = carrinho.find(item => item.produto_id === produtoId);
  const novaQuantidade = (existente?.quantidade || 0) + quantidade;

  if (novaQuantidade > produto.estoque) {
    alert("Quantidade maior que o estoque disponível.");
    return;
  }

  if (existente) {
    existente.quantidade = novaQuantidade;
  } else {
    carrinho.push({
      produto_id: produto.id,
      nome: produto.nome,
      preco: Number(produto.preco),
      quantidade
    });
  }

  renderizarCarrinho();
});

function renderizarCarrinho() {
  const tbody = document.getElementById("carrinho");
  tbody.innerHTML = "";

  carrinho.forEach((item, index) => {
    const subtotal = item.preco * item.quantidade;

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${item.nome}</td>
      <td>${item.quantidade}</td>
      <td>${dinheiro(item.preco)}</td>
      <td>${dinheiro(subtotal)}</td>
      <td><button class="action delete" onclick="removerItem(${index})">Remover</button></td>
    `;
    tbody.appendChild(tr);
  });

  const total = carrinho.reduce((soma, item) => soma + item.preco * item.quantidade, 0);
  document.getElementById("total").textContent = dinheiro(total);
}

function removerItem(index) {
  carrinho.splice(index, 1);
  renderizarCarrinho();
}

document.getElementById("finalizar").addEventListener("click", async () => {
  const mensagem = document.getElementById("mensagem");

  if (carrinho.length === 0) {
    mostrarMensagem("Adicione produtos à venda.", false);
    return;
  }

  const cliente_id = document.getElementById("cliente").value || null;

  const resposta = await fetch("/api/vendas", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cliente_id,
      itens: carrinho.map(item => ({
        produto_id: item.produto_id,
        quantidade: item.quantidade
      }))
    })
  });

  const dados = await resposta.json();

  if (!resposta.ok) {
    mostrarMensagem(dados.erro, false);
    return;
  }

  carrinho = [];
  renderizarCarrinho();
  mostrarMensagem(`Venda #${dados.id} registrada. Total: ${dinheiro(dados.total)}`, true);
  carregarDados();
});

function mostrarMensagem(texto, sucesso) {
  const mensagem = document.getElementById("mensagem");
  mensagem.textContent = texto;
  mensagem.className = `notice ${sucesso ? "success" : "error"}`;
}

function renderizarHistorico(vendas) {
  const tbody = document.getElementById("historico");
  tbody.innerHTML = "";

  vendas.forEach(venda => {
    const data = new Date(venda.data).toLocaleString("pt-BR");

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>#${venda.id}</td>
      <td>${venda.cliente}</td>
      <td>${data}</td>
      <td>${dinheiro(venda.valor_total)}</td>
    `;
    tbody.appendChild(tr);
  });
}

carregarDados();