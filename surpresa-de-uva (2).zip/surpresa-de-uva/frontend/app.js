const dinheiro = valor =>
  Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

async function carregarDashboard() {
  const status = document.getElementById("status");

  try {
    const resposta = await fetch("/api/dashboard");
    if (!resposta.ok) throw new Error("Não foi possível carregar os dados.");

    const dados = await resposta.json();

    document.getElementById("totalVendas").textContent = dinheiro(dados.totalVendas);
    document.getElementById("quantidadeVendas").textContent = dados.quantidadeVendas;
    document.getElementById("totalProdutos").textContent = dados.totalProdutos;
    document.getElementById("totalEstoque").textContent = dados.totalEstoque;

    status.className = "notice success";
    status.textContent = "Sistema conectado ao banco de dados.";
  } catch (erro) {
    status.className = "notice error";
    status.textContent = "Erro ao conectar ao servidor: " + erro.message;
  }
}

carregarDashboard();