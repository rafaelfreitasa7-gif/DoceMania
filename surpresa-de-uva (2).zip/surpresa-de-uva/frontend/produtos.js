let produtos = [];

async function carregarProdutos() {
  const resposta = await fetch("/api/produtos");
  produtos = await resposta.json();
  renderizarProdutos(produtos);
}

function renderizarProdutos(lista) {
  const tbody = document.getElementById("listaProdutos");
  tbody.innerHTML = "";

  lista.forEach(produto => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${produto.nome}</td>
      <td>${Number(produto.preco).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</td>
      <td class="${produto.estoque <= 5 ? "low-stock" : ""}">${produto.estoque}</td>
      <td>
        <button class="action edit" onclick="editarProduto(${produto.id})">Editar</button>
        <button class="action delete" onclick="excluirProduto(${produto.id})">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById("produtoForm").addEventListener("submit", async event => {
  event.preventDefault();

  const nome = document.getElementById("nome").value;
  const preco = document.getElementById("preco").value;
  const estoque = document.getElementById("estoque").value;

  const resposta = await fetch("/api/produtos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, preco, estoque })
  });

  const dados = await resposta.json();

  if (!resposta.ok) {
    alert(dados.erro);
    return;
  }

  event.target.reset();
  await carregarProdutos();
  alert("Produto cadastrado com sucesso!");
});

async function excluirProduto(id) {
  if (!confirm("Deseja excluir este produto?")) return;

  const resposta = await fetch(`/api/produtos/${id}`, { method: "DELETE" });
  const dados = await resposta.json();

  if (!resposta.ok) {
    alert(dados.erro);
    return;
  }

  carregarProdutos();
}

async function editarProduto(id) {
  const produto = produtos.find(p => p.id === id);
  if (!produto) return;

  const nome = prompt("Nome do produto:", produto.nome);
  if (nome === null) return;

  const preco = prompt("Preço:", produto.preco);
  if (preco === null) return;

  const estoque = prompt("Estoque:", produto.estoque);
  if (estoque === null) return;

  const resposta = await fetch(`/api/produtos/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, preco, estoque })
  });

  const dados = await resposta.json();

  if (!resposta.ok) {
    alert(dados.erro);
    return;
  }

  carregarProdutos();
}

document.getElementById("busca").addEventListener("input", event => {
  const termo = event.target.value.toLowerCase();
  renderizarProdutos(produtos.filter(p => p.nome.toLowerCase().includes(termo)));
});

carregarProdutos();