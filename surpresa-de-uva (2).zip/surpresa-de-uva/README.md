# 🍇 Surpresa de Uva

Sistema web acadêmico simples para gerenciamento de vendas de doces.

## Tecnologias

- HTML
- CSS
- JavaScript
- Node.js
- Express
- MySQL

## 1. Pré-requisitos

Instale:

- Node.js
- MySQL ou MySQL Server + MySQL Workbench

## 2. Criar o banco

Abra o MySQL Workbench e execute todo o conteúdo de:

`database/banco.sql`

Isso cria o banco `surpresa_uva`, as tabelas e alguns produtos iniciais.

## 3. Configurar o banco

O arquivo `backend/db.js` usa:

- host: localhost
- usuário: root
- senha: vazia
- banco: surpresa_uva

Se seu MySQL tiver senha, altere:

```js
password: process.env.DB_PASSWORD || ""
```

Ou use variáveis de ambiente.

## 4. Instalar as dependências

No terminal, dentro da pasta do projeto:

```bash
npm install
```

## 5. Executar

```bash
npm start
```

Depois abra:

http://localhost:3000

## Funcionalidades

- Dashboard
- Cadastro, edição e exclusão de produtos
- Controle de estoque
- Cadastro e exclusão de clientes
- Registro de vendas
- Carrinho de venda
- Baixa automática no estoque
- Histórico de vendas
- Cálculo automático do total

## Estrutura acadêmica sugerida

O projeto pode ser documentado com:

1. Introdução
2. Problema
3. Justificativa
4. Objetivo geral
5. Objetivos específicos
6. Requisitos funcionais e não funcionais
7. Diagrama de casos de uso
8. DER
9. Modelo lógico
10. Desenvolvimento
11. Testes
12. Resultados
13. Conclusão
