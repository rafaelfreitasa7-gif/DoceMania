CREATE DATABASE IF NOT EXISTS surpresa_uva
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE surpresa_uva;

CREATE TABLE IF NOT EXISTS cliente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    telefone VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS produto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NULL,
    data DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valor_total DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_venda_cliente
        FOREIGN KEY (cliente_id) REFERENCES cliente(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS item_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_venda_venda
        FOREIGN KEY (venda_id) REFERENCES venda(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_item_venda_produto
        FOREIGN KEY (produto_id) REFERENCES produto(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

INSERT INTO produto (nome, preco, estoque)
SELECT 'Surpresa de Uva', 5.00, 30
WHERE NOT EXISTS (
    SELECT 1 FROM produto WHERE nome = 'Surpresa de Uva'
);

INSERT INTO produto (nome, preco, estoque)
SELECT 'Brigadeiro', 3.00, 50
WHERE NOT EXISTS (
    SELECT 1 FROM produto WHERE nome = 'Brigadeiro'
);

INSERT INTO produto (nome, preco, estoque)
SELECT 'Beijinho', 3.00, 40
WHERE NOT EXISTS (
    SELECT 1 FROM produto WHERE nome = 'Beijinho'
);

INSERT INTO produto (nome, preco, estoque)
SELECT 'Morango com Chocolate', 6.00, 20
WHERE NOT EXISTS (
    SELECT 1 FROM produto WHERE nome = 'Morango com Chocolate'
);