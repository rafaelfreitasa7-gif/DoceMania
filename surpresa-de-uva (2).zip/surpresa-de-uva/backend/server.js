const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));


app.get("/api/dashboard", async (req, res) => {
  try {
    const [[vendas]] = await db.query(`
      SELECT
        COALESCE(SUM(valor_total), 0) AS totalVendas,
        COUNT(*) AS quantidadeVendas
      FROM venda
    `);

    const [[estoque]] = await db.query(`
      SELECT COALESCE(SUM(estoque), 0) AS totalEstoque
      FROM produto
    `);

    const [[produtos]] = await db.query(`
      SELECT COUNT(*) AS totalProdutos
      FROM produto
    `);

    const [[clientes]] = await db.query(`
      SELECT COUNT(*) AS totalClientes
      FROM cliente
    `);

    res.json({
      totalVendas: Number(vendas.totalVendas),
      quantidadeVendas: Number(vendas.quantidadeVendas),
      totalEstoque: Number(estoque.totalEstoque),
      totalProdutos: Number(produtos.totalProdutos),
      totalClientes: Number(clientes.totalClientes)
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});


app.get("/api/produtos", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT id, nome, preco, estoque
      FROM produto
      ORDER BY id DESC
    `);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.post("/api/produtos", async (req, res) => {
  try {
    const { nome, preco, estoque } = req.body;

    if (!nome || preco === undefined || estoque === undefined) {
      return res.status(400).json({
        erro: "Preencha todos os campos."
      });
    }

    if (Number(preco) < 0 || Number(estoque) < 0) {
      return res.status(400).json({
        erro: "Preço e estoque não podem ser negativos."
      });
    }

    const [result] = await db.query(
      `INSERT INTO produto (nome, preco, estoque)
       VALUES (?, ?, ?)`,
      [nome.trim(), Number(preco), Number(estoque)]
    );

    res.status(201).json({
      id: result.insertId,
      mensagem: "Produto cadastrado."
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.put("/api/produtos/:id", async (req, res) => {
  try {
    const { nome, preco, estoque } = req.body;
    const { id } = req.params;

    if (!nome || preco === undefined || estoque === undefined) {
      return res.status(400).json({
        erro: "Preencha todos os campos."
      });
    }

    if (Number(preco) < 0 || Number(estoque) < 0) {
      return res.status(400).json({
        erro: "Preço e estoque não podem ser negativos."
      });
    }

    await db.query(
      `UPDATE produto
       SET nome = ?, preco = ?, estoque = ?
       WHERE id = ?`,
      [nome.trim(), Number(preco), Number(estoque), id]
    );

    res.json({
      mensagem: "Produto atualizado."
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.delete("/api/produtos/:id", async (req, res) => {
  try {
    await db.query(
      "DELETE FROM produto WHERE id = ?",
      [req.params.id]
    );

    res.json({
      mensagem: "Produto excluído."
    });
  } catch (error) {
    if (error.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(400).json({
        erro: "Esse produto possui vendas registradas e não pode ser excluído."
      });
    }

    res.status(500).json({
      erro: error.message
    });
  }
});


app.get("/api/clientes", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT id, nome, telefone
      FROM cliente
      ORDER BY id DESC
    `);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.post("/api/clientes", async (req, res) => {
  try {
    const { nome, telefone } = req.body;

    if (!nome) {
      return res.status(400).json({
        erro: "Informe o nome do cliente."
      });
    }

    const [result] = await db.query(
      `INSERT INTO cliente (nome, telefone)
       VALUES (?, ?)`,
      [nome.trim(), telefone || null]
    );

    res.status(201).json({
      id: result.insertId,
      mensagem: "Cliente cadastrado."
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.delete("/api/clientes/:id", async (req, res) => {
  try {
    await db.query(
      "DELETE FROM cliente WHERE id = ?",
      [req.params.id]
    );

    res.json({
      mensagem: "Cliente excluído."
    });
  } catch (error) {
    if (error.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(400).json({
        erro: "Esse cliente possui vendas registradas e não pode ser excluído."
      });
    }

    res.status(500).json({
      erro: error.message
    });
  }
});

app.get("/api/vendas", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        v.id,
        v.data,
        v.valor_total,
        COALESCE(c.nome, 'Cliente não informado') AS cliente
      FROM venda v
      LEFT JOIN cliente c ON c.id = v.cliente_id
      ORDER BY v.id DESC
    `);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.post("/api/vendas", async (req, res) => {
  const connection = await db.getConnection();

  try {
    const { cliente_id, itens } = req.body;

    if (!Array.isArray(itens) || itens.length === 0) {
      return res.status(400).json({
        erro: "Adicione pelo menos um produto."
      });
    }

    await connection.beginTransaction();

    let total = 0;
    const itensProcessados = [];

    for (const item of itens) {
      const [rows] = await connection.query(
        `SELECT id, nome, preco, estoque
         FROM produto
         WHERE id = ?
         FOR UPDATE`,
        [item.produto_id]
      );

      if (rows.length === 0) {
        throw new Error("Produto não encontrado.");
      }

      const produto = rows[0];
      const quantidade = Number(item.quantidade);

      if (!Number.isInteger(quantidade) || quantidade <= 0) {
        throw new Error("Quantidade inválida.");
      }

      if (produto.estoque < quantidade) {
        throw new Error(
          `Estoque insuficiente para ${produto.nome}.`
        );
      }

      const subtotal =
        Number(produto.preco) * quantidade;

      total += subtotal;

      itensProcessados.push({
        produto_id: produto.id,
        quantidade,
        preco_unitario: produto.preco
      });
    }

    const [venda] = await connection.query(
      `INSERT INTO venda (cliente_id, valor_total)
       VALUES (?, ?)`,
      [cliente_id || null, total]
    );

    for (const item of itensProcessados) {
      await connection.query(
        `INSERT INTO item_venda
         (venda_id, produto_id, quantidade, preco_unitario)
         VALUES (?, ?, ?, ?)`,
        [
          venda.insertId,
          item.produto_id,
          item.quantidade,
          item.preco_unitario
        ]
      );

      await connection.query(
        `UPDATE produto
         SET estoque = estoque - ?
         WHERE id = ?`,
        [item.quantidade, item.produto_id]
      );
    }

    await connection.commit();

    res.status(201).json({
      id: venda.insertId,
      total,
      mensagem: "Venda registrada com sucesso."
    });
  } catch (error) {
    await connection.rollback();

    res.status(400).json({
      erro: error.message
    });
  } finally {
    connection.release();
  }
});

app.get("/*splat", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "frontend", "index.html")
  );
});

app.listen(PORT, () => {
  console.log(
    `Servidor rodando em http://localhost:${PORT}`
  );
});