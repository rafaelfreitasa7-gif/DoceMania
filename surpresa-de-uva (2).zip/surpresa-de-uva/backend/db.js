const mysql = require("mysql2/promise");
const db = mysql.createPool({

host: '127.0.0.1',
user: 'root',
password: '',
database: 'Surpresa_uva'

});

db.getConnection()
  .then((connection) => {
    console.log("Conectado com o banco de dados MySQL!");
    connection.release();
  })
  .catch((err) => {
    console.error("Erro ao conectar com o banco de dados:", err.message);
  });

module.exports = db;